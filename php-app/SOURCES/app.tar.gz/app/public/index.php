<?php

echo $hello;
echo 'hi';