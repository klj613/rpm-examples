<?php

$a = 10 / 0;
$a = $b;
echo 'hi hooo';
